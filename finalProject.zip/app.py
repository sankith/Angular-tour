from flask import Flask, redirect, url_for, render_template, request, session
from datetime import timedelta
import json
import plotly
import pandas as pd
import plotly.express as px

from Final import fetchStockData, monthwise_comparison

app = Flask(__name__)
app.secret_key = 'stockpredictorkey'
app.permanent_session_lifetime = timedelta(minutes=10)

user_details = {
    'sandeep@gmail.com':'sandeep', 'saiteja@gmail.com':'saiteja', 'vaibhav@gmail.com':'vaibhav'
}

@app.route('/')
def root():
    return redirect(url_for('login'))

@app.route('/login', methods=["POST", 'GET'])
def login():
    if request.method == 'POST':
        form_details = request.form.to_dict()
        try:
            if user_details.get(form_details['email'],None) == form_details['password']:
                session.permanent = True
                session['email'] = form_details['email']
                return redirect(url_for('home'))
        except Exception as err:
            if 'email' in session:
                session.pop('email',None)
            return render_template('login.html')
    else:
        if 'email' in session:
            return redirect(url_for('home'))
        return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('email',None)
    return redirect(url_for('login'))

@app.route('/home', methods = ["POST","GET"])
def home():
    if 'email' in session:
        if request.method == "POST":
            form_details = request.form.to_dict()
            try:
                symbol = form_details['symbol'].strip()
                time = form_details['period'].strip()
                print(form_details,symbol,time)
                stock_data = fetchStockData(symbol, time)
                fig = monthwise_comparison(stock_data)
                graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
                return render_template('home.html', graphJSON=graphJSON, btntext = 'Logout')
            except KeyError as err:
                    return render_template('home.html', btntext = 'Logout', error = f'Symbol {form_details["symbol"].strip()} is not found.')
            except Exception as err:
                return render_template('home.html', btntext = 'Logout')
        else:
            return render_template('home.html', btntext = 'Logout')
    else:
        return redirect(url_for('logout'))


if __name__ == "__main__":
    app.run(debug=True)
